def hello(name):
    return f'Ola, {name}, tenha um bom dia'
from metods.hello import hello

print(hello('Ezequiel'))